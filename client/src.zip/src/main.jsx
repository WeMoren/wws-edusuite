import { BrowserRouter } from "react-router-dom"
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { AuthProvider } from "./auth/AuthContext";

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
         <AuthProvider>
             <App />
         </AuthProvider>
    </BrowserRouter>
    
  </StrictMode>,
)
